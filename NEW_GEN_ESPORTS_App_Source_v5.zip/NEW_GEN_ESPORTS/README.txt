NEW GEN ESPORTS — Tournament App prototype

Open index.html in a browser to preview. For installable PWA behavior, serve this folder over HTTPS (or localhost) and open it in Chrome, then use Install app / Add to Home Screen.

Included: player profile, tournament listing and local registration, admin demo panel, room details, leaderboard and results.

IMPORTANT:
- This is a front-end prototype, not a production online service and not a compiled Android APK.
- Data is stored in the browser's localStorage on one device. No real accounts, cross-device sync, payment gateway, server database, or secure admin authentication exists yet.
- Configured demo admins: fahimislam231212@gmail.com / 01966791507 and ebmaruf@gmail.com / 01316053793 or +8801316053793. The prototype admin screen checks both values plus the demo password, but all checks are client-side and can be bypassed. Demo admin password: NGadmin123. This email/password check is client-side and can be bypassed; replace it with server-side authentication before public use.
- Payment status is only a placeholder. Verify payments manually until a legitimate payment provider is integrated.
- Never publish actual room credentials in public builds; reveal them only to approved registered players using server-side access rules.

To create a real online release: configure backend (e.g. Firebase/Supabase), secure authentication and database rules, payment verification, then package the hosted app in an Android WebView/TWA project and sign the APK/AAB with Android build tools.
