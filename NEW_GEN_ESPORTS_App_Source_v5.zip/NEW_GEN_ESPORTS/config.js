// DEMO ONLY: client-side admin checks are not secure for a public online app.
// Bangladesh local and +880 phone formats are both accepted.
window.NG_CONFIG = {
  admins: [
    { email: "fahimislam231212@gmail.com", phones: ["01966791507", "+8801966791507"] },
    { email: "ebmaruf@gmail.com", phones: ["01316053793", "+8801316053793"] }
  ]
};
